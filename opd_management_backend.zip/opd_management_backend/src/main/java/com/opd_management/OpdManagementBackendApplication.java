package com.opd_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpdManagementBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpdManagementBackendApplication.class, args);
		System.out.println("Opd Management Project Running......");
	}

}
