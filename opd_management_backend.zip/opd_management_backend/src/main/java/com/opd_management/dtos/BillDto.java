package com.opd_management.dtos;

import java.math.BigDecimal;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

// FrontEnd Data Temporary Store    
public class BillDto {
	
	@NotNull(message = "Consultation fee is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Consultation fee must be greater than 0")
	private BigDecimal consultation_fee;
	
	@NotBlank(message = "Payment status is required")
    @Pattern(
        regexp = "^(PAID|UNPAID|PENDING)$",
        message = "Payment status must be PAID, UNPAID, or PENDING"
    )
	private String payment_status;
	
	@NotBlank(message = "Payment mode is required")
    @Pattern(
        regexp = "^(CASH|UPI|CARD|ONLINE)$",
        message = "Payment mode must be CASH, UPI, CARD, or ONLINE"
    )
	private String payment_mode;
	
	@NotNull(message = "Concession value is required")
    @DecimalMin(value = "0.0", message = "Concession cannot be negative")
	private BigDecimal concession;
	
	@NotNull(message = "Paid amount is required")
    @DecimalMin(value = "0.0", message = "Paid amount cannot be negative")
	private BigDecimal paid_amount;
	
	@NotNull(message = "Total amount is required")
    @DecimalMin(value = "0.0", message = "Total amount cannot be negative")
	private BigDecimal total_amount;
	
	@NotNull(message = "Pending amount is required")
    @DecimalMin(value = "0.0", message = "Pending amount cannot be negative")
	private BigDecimal pending_amount;
	
//	@NotBlank(message = "Created date is required")
//	private LocalDateTime created_at;
	
	@NotNull(message = "Id must be required")
	@Positive(message = "ID must be positive")
	private int visitid;

	public BigDecimal getConsultation_fee() {
		return consultation_fee;
	}

	public void setConsultation_fee(BigDecimal consultation_fee) {
		this.consultation_fee = consultation_fee;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	public BigDecimal getConcession() {
		return concession;
	}

	public void setConcession(BigDecimal concession) {
		this.concession = concession;
	}

	public BigDecimal getPaid_amount() {
		return paid_amount;
	}

	public void setPaid_amount(BigDecimal paid_amount) {
		this.paid_amount = paid_amount;
	}

	public BigDecimal getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(BigDecimal total_amount) {
		this.total_amount = total_amount;
	}

	public BigDecimal getPending_amount() {
		return pending_amount;
	}

	public void setPending_amount(BigDecimal pending_amount) {
		this.pending_amount = pending_amount;
	}

//	public LocalDateTime getCreated_at() {
//		return created_at;
//	}
//
//	public void setCreated_at(LocalDateTime created_at) {
//		this.created_at = created_at;
//	}

	public int getVisitid() {
		return visitid;
	}

	public void setVisitid(int visitid) {
		this.visitid = visitid;
	}

	
}
