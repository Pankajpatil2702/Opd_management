package com.opd_management.entities;

public enum Role {

	ADMIN,
	DOCTOR,
	RECEPTIONIST
}
