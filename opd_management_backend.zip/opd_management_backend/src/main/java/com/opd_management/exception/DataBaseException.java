package com.opd_management.exception;

public class DataBaseException extends RuntimeException {
		
	public DataBaseException(String message) {
		super(message);
	}
}
