package com.opd_management.exception;

public class DuplicateResourceException extends RuntimeException {
		public DuplicateResourceException(String message) {
			super(message);
		}
}
