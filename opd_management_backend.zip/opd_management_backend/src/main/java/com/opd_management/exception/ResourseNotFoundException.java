package com.opd_management.exception;

public class ResourseNotFoundException extends RuntimeException{
	
	public ResourseNotFoundException(String message) {
		
		super(message);
	}

}
